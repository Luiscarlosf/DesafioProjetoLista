package br.com.luiscarlosfn.DesafioLista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioListaApplicationTests {

	@Test
	void contextLoads() {
	}

}
